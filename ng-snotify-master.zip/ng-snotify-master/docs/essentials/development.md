# Development

###### This is the fast guide how to run development

- Run example app `npm start`
- open `localhost:8080` in your browser
- go to `./src`
- Start developing!

In the end you should re-link lib to the `dist` folder, and test

- `npm run example:build`
- Be sure you pass `npm run lib:lint` and `npm test`
- Make a pull request
