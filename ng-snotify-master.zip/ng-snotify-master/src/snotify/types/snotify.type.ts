export type SnotifyType
  = 'simple'
  | 'success'
  | 'error'
  | 'warning'
  | 'info'
  | 'async'
  | 'confirm'
  | 'prompt';
