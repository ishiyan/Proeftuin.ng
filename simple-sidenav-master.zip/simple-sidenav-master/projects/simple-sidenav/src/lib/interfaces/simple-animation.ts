export interface SimpleAnimation {
  in?: { value: string; duration?: string|number };
  out?: { value: string; duration?: string|number };
}
