/*
 * Public API Surface of simple-sidenav
 */

export * from './lib/simple-sidenav.component';
export * from './lib/simple-sidenav.module';
export * from './lib/interfaces/simple-menu';
