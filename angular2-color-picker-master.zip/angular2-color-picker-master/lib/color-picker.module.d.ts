export declare class ColorPickerModule {
}
